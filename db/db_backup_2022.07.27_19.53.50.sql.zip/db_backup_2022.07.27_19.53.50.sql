-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
-- -------------------------------------------
-- START BACKUP
-- -------------------------------------------
-- -------------------------------------------
-- TABLE `category`
-- -------------------------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `image`
-- -------------------------------------------
DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filePath` varchar(400) NOT NULL,
  `itemId` int DEFAULT NULL,
  `isMain` tinyint(1) DEFAULT NULL,
  `modelName` varchar(150) NOT NULL,
  `urlAlias` varchar(400) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `menu`
-- -------------------------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text,
  `price` float DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `hit` enum('0','1') NOT NULL,
  `new` enum('0','1') NOT NULL,
  `sale` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `migration`
-- -------------------------------------------
DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `order_items`
-- -------------------------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `dish_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `qty_item` int NOT NULL,
  `sum_item` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `orders`
-- -------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `qty` int NOT NULL,
  `sum` float NOT NULL,
  `status` enum('0','1') NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE `users`
-- -------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'user',
  `auth_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -------------------------------------------
-- TABLE DATA category
-- -------------------------------------------
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('1','0','Бургери','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('2','0','Піца','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('3','0','Картопля','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('4','0','Напої','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('5','0','Соуси','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('6','1','Бургери з яловичини','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('7','1','Бургери зі свинини','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('8','1','Бургери з курятини','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('9','1','Вегетаріанські бургери','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('10','2','Звичайна піца','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('11','2','Гостра піца','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('12','2','Піца з морепродуктами','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('13','2','Вегетаріанська піца','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('14','3','Картопля фрі','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('15','3','Картопля по селянськи','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('16','4','Газовані напої','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('17','4','Сок','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('18','4','Вода','','');;;
INSERT INTO `category` (`id`,`parent_id`,`name`,`keywords`,`description`) VALUES
('19','0','123','123','123');;;
-- -------------------------------------------
-- TABLE DATA image
-- -------------------------------------------
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('3','Menus/Menu7/ba53eb.jpg','7','1','Menu','839217e221-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('4','Menus/Menu8/b113b5.png','8','1','Menu','5077d022a3-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('5','Menus/Menu9/dcab69.png','9','1','Menu','accafd76cb-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('7','Menus/Menu10/f6b03e.png','10','1','Menu','7e8e27f99a-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('9','Menus/Menu11/194bd5.png','11','1','Menu','e6842ec8dd-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('10','Menus/Menu12/904b56.png','12','1','Menu','5d0ddbb5d3-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('11','Menus/Menu13/216e13.png','13','1','Menu','b388e7c592-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('17','Menus/Menu14/fb73e3.png','14','1','Menu','09963993d1-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('19','Menus/Menu15/d6ae39.png','15','1','Menu','ce1f164a53-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('20','Menus/Menu16/727362.jpg','16','1','Menu','f9ae07bb1b-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('21','Menus/Menu17/045146.png','17','1','Menu','e0b900cc68-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('22','Menus/Menu18/ecc2ec.png','18','1','Menu','5849c44572-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('23','Menus/Menu19/0c44c0.png','19','1','Menu','c8ea2e0b72-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('24','Menus/Menu20/4c1d9b.jpg','20','1','Menu','a58508fe0a-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('27','Menus/Menu21/3ff67e.png','21','1','Menu','8e8b385fba-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('28','Menus/Menu22/077c81.png','22','1','Menu','998dde4e82-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('30','Menus/Menu23/6c0349.png','23','1','Menu','39d7c1ff8f-1','');;;
INSERT INTO `image` (`id`,`filePath`,`itemId`,`isMain`,`modelName`,`urlAlias`,`name`) VALUES
('31','Menus/Menu24/317436.png','24','1','Menu','be206e5e67-1','');;;
-- -------------------------------------------
-- TABLE DATA menu
-- -------------------------------------------
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('7','8','Чікен-класік','<p>Бургер з делікатною курячою котлетою та свіжими овочами</p>
','55','Бургер','Смачний бургер','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('8','6','Фреш-бургер','<p>Бургер зі смачною соковитою котлетою з яловичини і великою кількістю овочів</p>
','75','','','1','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('9','8','Дабл чікен-бургер','<p>Бургер з двома курячими котлетами та листями салату</p>
','85','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('10','7','Дабл роял-бургер','<p>Бургер з двома котлетами зі свинини&nbsp;та фірмовим соусом</p>
','105','','','1','0','1');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('11','6','Бургер екстра-бекон','<p>Бургер з котлетою з яловичини, рубленим беконом заленим салатом та овочами</p>
','90','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('12','7','Барбекю-бургер','<p>Бургер с двома котлетами зі свинини&nbsp;та фірмовим соусом-барбекю</p>
','100','','','0','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('13','6','Біг- класік-бургер','<p>Бургер з&nbsp; двома великики апетитними котлетами з яловичини та ніжним сиром&nbsp;</p>
','95','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('14','9','Вегетаріанський гамбургер','<p>Бургер з&nbsp;котлетою із сої&nbsp;та свіжими овочами</p>
','75','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('15','10','Папероні','<p>Смачана піца</p>
','120','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('16','11','Діабло','<p>Гостра смачна піца</p>
','130','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('17','12','Морський Бриз','<p>Смачна піца з морепродуктами</p>
','160','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('18','13','Сицилійська піца','<p>Смачна вегетаріанська піца</p>
','130','','','1','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('19','14','Картопля фрі','<p>Хрумка апетитна картопля обсмажена у фретюрі на відбірній соняшниковій олії&nbsp;</p>
','45','','','1','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('20','15','Картопля по селянськи','<p>Смачна картопля по селянськи</p>
','55','','','0','1','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('21','16','Кока-кола','<p>Прохолодна кола</p>
','25','','','0','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('22','17','Сік Апельсиновий','<p>Смачний апельсиновий сік</p>
','35','','','0','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('23','18','Вода','<p>Прохолодна вода</p>
','20','','','0','0','0');;;
INSERT INTO `menu` (`id`,`category_id`,`name`,`content`,`price`,`keywords`,`description`,`hit`,`new`,`sale`) VALUES
('24','5','Кетчуп','<p>Кетчуп з томатів</p>
','10','','','0','1','0');;;
-- -------------------------------------------
-- TABLE DATA migration
-- -------------------------------------------
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m000000_000000_base','1658496135');;;
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m140622_111540_create_image_table','1658496142');;;
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m140622_111545_add_name_to_image_table','1658496142');;;
-- -------------------------------------------
-- TABLE DATA order_items
-- -------------------------------------------
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('22','10','8','Фреш-бургер','75','1','75');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('23','10','9','Дабл чікен-бургер','85','1','85');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('24','10','7','Чікен-класік','55','1','55');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('28','12','15','Папероні','120','2','240');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('29','12','18','Сицилійська піца','130','1','130');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('31','13','11','Бургер екстра-бекон','90','2','180');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('32','13','14','Вегетаріанський гамбургер','75','1','75');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('33','13','21','Кока-кола','25','1','25');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('34','14','13','Біг- класік-бургер','95','2','190');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('35','14','16','Діабло','130','1','130');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('36','14','19','Картопля фрі','45','1','45');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('37','14','24','Кетчуп','10','1','10');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('38','15','8','Фреш-бургер','75','1','75');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('39','15','22','Сік Апельсиновий','35','1','35');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('40','16','8','Фреш-бургер','75','1','75');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('41','16','23','Вода','20','1','20');;;
INSERT INTO `order_items` (`id`,`order_id`,`dish_id`,`name`,`price`,`qty_item`,`sum_item`) VALUES
('42','16','16','Діабло','130','1','130');;;
-- -------------------------------------------
-- TABLE DATA orders
-- -------------------------------------------
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('10','1','2022-05-27 14:47:48','2022-07-27 14:47:48','3','215','1','Даніїл','daniilbaranovskiy03@gmail.com','+380961610434','test');;;
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('12','3','2022-06-27 14:50:16','2022-07-27 14:50:16','4','415','1','Денис','denis@gmail.com','+380961610434','test');;;
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('13','5','2022-07-27 14:51:50','2022-07-27 14:51:50','4','280','0','Петро','petro@gmail.com','+380971193031','test');;;
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('14','4','2022-07-27 14:52:47','2022-07-27 14:52:47','5','375','0','Діма','dima@gmail.com','+380961610533','test');;;
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('15','1','2022-07-27 15:06:03','2022-07-27 15:06:03','2','110','0','Даніїл','daniilbaranovskiy03@gmail.com','+380961610434','test');;;
INSERT INTO `orders` (`id`,`user_id`,`created_at`,`updated_at`,`qty`,`sum`,`status`,`name`,`email`,`phone`,`address`) VALUES
('16','3','2022-07-27 19:51:19','2022-07-27 19:51:19','3','225','0','Денис','denis@gmail.com','+380961610434','test');;;
-- -------------------------------------------
-- TABLE DATA users
-- -------------------------------------------
INSERT INTO `users` (`id`,`username`,`password`,`firstname`,`lastname`,`number`,`city`,`role`,`auth_key`) VALUES
('1','admin','$2y$13$6oeI0Vm4hOC9R7zWixSkFObZhoBFhR3uLVS9MCml4lqRGsoFRKnQi','Даніїл','Барановський','+380961610434','Житомир','admin','47pbGW9Ao8sj1jennlF4At6LMGACfxEK');;;
INSERT INTO `users` (`id`,`username`,`password`,`firstname`,`lastname`,`number`,`city`,`role`,`auth_key`) VALUES
('3','ReKaRR','$2y$13$H7aP2Xtm2XdrIyIKW2H/XOrwVpJZlT0LfmTTZfmev7J00zwsIcbTe','Денис','Поліщук','+380961610434','Житомир','user','I6qQnG46mkY2WJxwYm32HQukRTmxdBGM');;;
INSERT INTO `users` (`id`,`username`,`password`,`firstname`,`lastname`,`number`,`city`,`role`,`auth_key`) VALUES
('4','dima','$2y$13$hxbvauh9qH6Lp0ViHpriTeTmyABsd9x4AsP3plOdKlxT9O0pKmrEW','Діма','Березовський','+380961610533','Житомир','user','pA9sIWYTp1XEFhD2VIMnM7fXmU0uph0_');;;
INSERT INTO `users` (`id`,`username`,`password`,`firstname`,`lastname`,`number`,`city`,`role`,`auth_key`) VALUES
('5','petro','$2y$13$svWzHuSktA.4yuuPNZz8EO8Ie2OwtIN988OU20s9gX2fIWgN/YazO','Петро','Моставчук','+380971193031','Житомир','user','ZpWKSkXrG-PLXz1B_8yqV2d_Qmrw_bxO');;;
-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
-- -------------------------------------------
-- -------------------------------------------
-- END BACKUP
-- -------------------------------------------
